// 설정용 파일
// http://localhost:8989


const API_HOST = "localhost"; //호스팅 컴퓨터 (127.0.0.1)

const API_PORT = "8989"
//export로 외부로 연결
export const API_BASE_URL = `http://${API_HOST}:${API_PORT}`;