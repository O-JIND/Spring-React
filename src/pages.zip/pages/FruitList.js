function App() {
    return (
        <>
            Some Fruits
        </>
    )
}
export default App;