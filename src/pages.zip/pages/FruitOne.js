function App() {
    return (
        <>
            A Fruit
        </>
    )
}
export default App;